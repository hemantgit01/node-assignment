1. The port of js is set to 3001, you can change the listening port to any available 
2. To change open main.js and move to last line and change the port from 3001 to any
3. download node_modules using the 'npm install' commmand 
4. after downloading the node modules run the main.js using 'node main'
5. open browser and type the URL=> localhost:<port>/  

currently port is 3001


